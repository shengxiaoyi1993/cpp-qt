var searchData=
[
  ['pretransfertime',['preTransferTime',['../struct_rest_client_1_1_connection_1_1_request_info.html#abcccb563d60a3f5325918ef912130e16',1,'RestClient::Connection::RequestInfo']]]
];
