var searchData=
[
  ['requestinfo',['RequestInfo',['../struct_rest_client_1_1_connection_1_1_request_info.html',1,'RestClient::Connection']]],
  ['response',['Response',['../struct_rest_client_1_1_response.html',1,'RestClient']]]
];
